
'use client'
import mapboxgl from 'mapbox-gl'
import 'mapbox-gl/dist/mapbox-gl.css'
import { useEffect, useRef } from 'react'
mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || ''
export default function Map(){
  const el=useRef<HTMLDivElement>(null)
  useEffect(()=>{
    if(!el.current) return
    const map=new mapboxgl.Map({container:el.current,style:'mapbox://styles/mapbox/streets-v12',center:[46.6753,24.7136],zoom:4.5})
    map.addControl(new mapboxgl.NavigationControl())
    return ()=>map.remove()
  },[])
  return <div ref={el} className="w-full h-screen"/>
}
