
export default function AddPage(){
  return (<main className="container mx-auto p-6">
    <h1 className="text-2xl font-bold mb-4">توثيق إحساسي</h1>
    <form action="/api/entries" method="post" encType="multipart/form-data" className="grid gap-3 max-w-2xl">
      <input name="placeName" placeholder="اسم المكان" className="border p-2 rounded"/>
      <div className="grid grid-cols-2 gap-2">
        <input name="lat" placeholder="Latitude" className="border p-2 rounded"/>
        <input name="lng" placeholder="Longitude" className="border p-2 rounded"/>
      </div>
      <input type="datetime-local" name="takenAt" className="border p-2 rounded"/>
      <input name="emotions" placeholder="المشاعر (مفصولة بفواصل)" className="border p-2 rounded"/>
      <input type="file" name="image" accept="image/*"/>
      <input type="file" name="audio" accept="audio/*"/>
      <textarea name="text" placeholder="اكتب قصتك..." className="border p-2 rounded min-h-[120px]"/>
      <button className="bg-brand.primary text-white rounded px-4 py-2 w-fit">وثّق إحساسي</button>
    </form>
  </main>)
}
