
import { NextRequest, NextResponse } from 'next/server'
import { saveLocal } from '@/lib/storage'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest){
  const fd = await req.formData()
  const placeName = String(fd.get('placeName')||'')
  const lat = parseFloat(String(fd.get('lat')||'0'))
  const lng = parseFloat(String(fd.get('lng')||'0'))
  const takenAt = new Date(String(fd.get('takenAt')||new Date().toISOString()))
  const emotions = String(fd.get('emotions')||'').split(',').map(s=>s.trim()).filter(Boolean)
  const text = String(fd.get('text')||'')
  const img = fd.get('image') as unknown as File | null
  const aud = fd.get('audio') as unknown as File | null
  let mediaImage: string | null = null
  let mediaAudio: string | null = null
  if(img && typeof img==='object'){ mediaImage = await saveLocal(img,'images') }
  if(aud && typeof aud==='object'){ mediaAudio = await saveLocal(aud,'audio') }
  const entry = await prisma.entry.create({ data: { userId: 'demo', placeName, lat, lng, takenAt, emotions, text, mediaImage, mediaAudio } })
  return NextResponse.json({ id: entry.id })
}

export async function GET(){
  const entries = await prisma.entry.findMany({ orderBy: { createdAt: 'desc' }, take: 50 })
  return NextResponse.json(entries)
}
