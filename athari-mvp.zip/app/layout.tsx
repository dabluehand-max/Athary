
import './globals.css'
export const metadata = { title: 'أثاري', description: 'خريطة المشاعر' }
export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="ar" dir="rtl"><body className="bg-brand.neutral">{children}</body></html>
}
