
'use client'
import dynamic from 'next/dynamic'
const Map = dynamic(()=>import('@/components/Map'),{ssr:false})
export default function MapPage(){
  return <main className="min-h-screen"><Map/></main>
}
