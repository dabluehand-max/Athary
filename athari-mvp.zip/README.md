# أثاري – MVP (Next.js + Mapbox + Prisma)

راجع التعليمات داخل المشروع للتشغيل.
