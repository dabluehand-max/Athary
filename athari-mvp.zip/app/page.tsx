
'use client'
import Link from 'next/link'
export default function Home(){
  return (<main className="min-h-screen grid place-items-center p-6">
    <div className="max-w-2xl w-full grid gap-6 text-center">
      <h1 className="text-4xl font-bold">أثاري</h1>
      <p>وش تبغى تسوي اليوم؟</p>
      <div className="grid md:grid-cols-2 gap-4">
        <Link href="/add" className="rounded-2xl p-6 bg-brand.secondary text-white">أوثّق إحساسي</Link>
        <Link href="/map" className="rounded-2xl p-6 bg-brand.primary text-white">أحسّ</Link>
      </div>
    </div>
  </main>)
}
