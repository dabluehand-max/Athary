
import fs from 'fs'
import path from 'path'
const dir = path.join(process.cwd(),'public','uploads')
if(!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true})
export async function saveLocal(file: File, sub: 'images'|'audio'){
  const ab = await file.arrayBuffer()
  const buf = Buffer.from(ab)
  const folder = path.join(dir, sub)
  if(!fs.existsSync(folder)) fs.mkdirSync(folder,{recursive:true})
  const filename = `${Date.now()}-${(file as any).name || 'file'}`.replace(/\s+/g,'_')
  const out = path.join(folder, filename)
  await fs.promises.writeFile(out, buf)
  return `/uploads/${sub}/${filename}`
}
